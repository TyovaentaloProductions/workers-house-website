(() => {
  console.log("Hello from roadmap.js!");
})();