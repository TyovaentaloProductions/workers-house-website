/**
 * This is and object for configuration things.
 * Do not modify this file at all.
 * We are using static local data for testing purposes so.
 * In order to do that we will override the URL configuration in this file.
 */
const config = {
  // Remote URL
  baseURL: "https://tie-lukioplus.rd.tuni.fi/corona/api/"
};